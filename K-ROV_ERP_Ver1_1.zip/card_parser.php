<?php
/**
 * /includes/card_parser.php
 * OCR 원문 텍스트 → 명함 항목 추출.
 *
 * 한국 명함의 일반적인 배치를 전제로 한다.
 *   · 라벨(TEL/FAX/MOBILE/E-MAIL/HOME 또는 전화/팩스/휴대폰/이메일)이 붙는 경우가 많다.
 *   · 이름은 "신 유 철" 처럼 글자 사이를 띄우는 경우가 흔하다.
 *   · 부서/직위는 "기업지원단 기업성장지원팀 / 전임연구원" 처럼 / 로 구분된다.
 * 추출 실패해도 사용자가 확인 화면에서 수정하므로, 확신이 낮으면 비워 둔다.
 */

/** 전화번호 정규화 : 01099604701 → 010-9960-4701 */
function card_normalize_phone(string $v): string
{
    $v = trim($v);
    // +82-10-1234-5678 / 82 2 123 4567 → 국내 표기로 환원
    if (preg_match('/^\+?82[\-\.\s]?0?(\d.*)$/', $v, $m)) {
        $v = '0' . $m[1];
    }
    $d = preg_replace('/[^0-9]/', '', $v);
    if ($d === '') {
        return '';
    }
    if (preg_match('/^01[016789]\d{7,8}$/', $d)) {
        return strlen($d) === 11
            ? substr($d, 0, 3) . '-' . substr($d, 3, 4) . '-' . substr($d, 7)
            : substr($d, 0, 3) . '-' . substr($d, 3, 3) . '-' . substr($d, 6);
    }
    if (strpos($d, '02') === 0 && strlen($d) >= 9) {
        return '02-' . substr($d, 2, strlen($d) - 6) . '-' . substr($d, -4);
    }
    if (preg_match('/^0\d{2}\d{7,8}$/', $d)) {
        return substr($d, 0, 3) . '-' . substr($d, 3, strlen($d) - 7) . '-' . substr($d, -4);
    }
    if (preg_match('/^(1[5-9]\d{2})(\d{4})$/', $d, $m)) {
        return $m[1] . '-' . $m[2];               // 대표번호 1588-0000
    }
    return trim($v);
}

/**
 * 명함 원문에서 항목을 추출한다.
 * @return array{name:string,company_name:string,dept_name:string,position:string,
 *               mobile:string,tel:string,fax:string,email:string,homepage:string,
 *               zipcode:string,address:string}
 */
function parse_card_text(string $text): array
{
    $out = ['name'=>'','company_name'=>'','dept_name'=>'','position'=>'','mobile'=>'','tel'=>'',
            'fax'=>'','email'=>'','homepage'=>'','zipcode'=>'','address'=>''];
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    if (trim($text) === '') {
        return $out;
    }

    $lines = [];
    foreach (explode("\n", $text) as $l) {
        $l = trim(preg_replace('/[\x{00A0}\t]+/u', ' ', $l));
        $l = preg_replace('/ {2,}/', ' ', $l);
        if ($l !== '') {
            $lines[] = $l;
        }
    }
    $flat = implode(' ', $lines);

    /* 1) 이메일 --------------------------------------------------- */
    if (preg_match('/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', $flat, $m)) {
        $out['email'] = $m[0];
    }

    /* 2) 홈페이지 ------------------------------------------------- */
    if (preg_match('#(https?://[A-Za-z0-9./_\-]+|www\.[A-Za-z0-9./_\-]+)#', $flat, $m)) {
        $out['homepage'] = rtrim($m[0], '.,');
    }

    /* 3) 라벨이 붙은 전화번호 -------------------------------------- */
    $labelMap = [
        'mobile' => 'MOBILE|M\.P|H\.P|HP|CELL|PHONE|휴대폰|휴대전화|핸드폰|모바일',
        'fax'    => 'FAX|F\.|팩스',
        'tel'    => 'TEL|T\.|PH|전화|대표전화|사무실',
    ];
    $numPattern = '[0-9][0-9\-\.\s\)\(]{6,20}[0-9]';
    foreach ($labelMap as $key => $labels) {
        if (preg_match('/(?:' . $labels . ')\s*[.:）)]?\s*(' . $numPattern . ')/iu', $flat, $m)) {
            $out[$key] = card_normalize_phone($m[1]);
        }
    }

    /* 4) 라벨 없는 번호 보완 : 010으로 시작하면 휴대전화 ------------- */
    if ($out['mobile'] === '' && preg_match('/(?:\+?82[\-\.\s]?)?0?1[016789][\-\.\s]?\d{3,4}[\-\.\s]?\d{4}/', $flat, $m)) {
        $out['mobile'] = card_normalize_phone($m[0]);
    }
    if ($out['tel'] === '') {
        if (preg_match_all('/0(?:2|[3-6][1-5]|70|50\d)[\-\.\s]?\d{3,4}[\-\.\s]?\d{4}/', $flat, $ms)) {
            foreach ($ms[0] as $cand) {
                $norm = card_normalize_phone($cand);
                if ($norm !== $out['fax'] && $norm !== $out['mobile']) {
                    $out['tel'] = $norm;
                    break;
                }
            }
        }
    }

    /* 5) 우편번호 + 주소 ------------------------------------------ */
    if (preg_match('/[\(\[]?\b(\d{5})\b[\)\]]?/u', $flat, $m)) {
        $out['zipcode'] = $m[1];
    }
    foreach ($lines as $l) {
        if (preg_match('/(특별자치시|특별자치도|특별시|광역시|[가-힣]{2,}(?:시|군|구))/u', $l)
            && preg_match('/(로|길|동|읍|면|가)\s?\d|\d+(번길|-\d+)/u', $l)) {
            $addr = preg_replace('/^[\(\[]?\d{5}[\)\]]?\s*/u', '', $l);
            $addr = preg_replace('/(?:주소|ADDRESS|ADD)\s*[.:]\s*/iu', '', $addr);
            if (mb_strlen($addr) >= 8) {
                $out['address'] = trim($addr);
                break;
            }
        }
    }

    /* 6) 회사명 --------------------------------------------------- */
    $corpWords = '\(주\)|\(재\)|\(사\)|㈜|㈐|주식회사|재단법인|사단법인|유한회사|합자회사|테크노파크|진흥원|연구원|연구소|센터|협회|조합|공사|공단|병원|대학교|Co\.|Corp|Inc|Ltd|Company';
    $best = '';
    foreach ($lines as $l) {
        if (preg_match('/' . $corpWords . '/iu', $l)
            && !preg_match('/@|https?:|TEL|FAX|MOBILE/iu', $l)
            && mb_strlen($l) <= 40) {
            $cand = trim($l);
            // 로고 옆 슬로건 등 너무 긴 줄은 제외, 짧고 법인격이 명확한 줄 우선
            if ($best === '' || mb_strlen($cand) < mb_strlen($best)) {
                $best = $cand;
            }
        }
    }
    $out['company_name'] = $best;

    /* 7) 부서 / 직위 ---------------------------------------------- */
    $posWords = '회장|부회장|사장|부사장|대표이사|대표|이사장|이사|감사|본부장|실장|센터장|단장|소장|원장|팀장|파트장|부장|차장|과장|대리|주임|사원|연구원|전임연구원|선임연구원|책임연구원|수석|책임|선임|매니저|컨설턴트|엔지니어|디자이너|기사|주무관|사무관|대표변호사|세무사|회계사';
    foreach ($lines as $l) {
        if ($l === $out['company_name'] || preg_match('/@|https?:|\d{2,}/u', $l)) {
            continue;
        }
        if (preg_match('/' . $posWords . '/u', $l)) {
            if (strpos($l, '/') !== false) {
                [$a, $b] = array_map('trim', explode('/', $l, 2));
                // "부서 / 직위" 순서가 일반적이나 반대인 경우도 처리
                if (preg_match('/' . $posWords . '/u', $b)) {
                    $out['dept_name'] = $a;
                    $out['position']  = $b;
                } else {
                    $out['dept_name'] = $b;
                    $out['position']  = $a;
                }
            } elseif (preg_match('/^(.*?)\s*(' . $posWords . ')$/u', $l, $m)) {
                $out['dept_name'] = trim($m[1]);
                $out['position']  = trim($m[2]);
            } else {
                $out['position'] = $l;
            }
            break;
        }
    }
    // 직위 줄에 이름이 섞인 경우 분리 (예: "홍길동 팀장")
    if ($out['position'] !== '' && preg_match('/^([가-힣]{2,4})\s+(' . $posWords . ')$/u', $out['position'], $m)) {
        $out['name']     = $m[1];
        $out['position'] = $m[2];
    }
    // "세무사 박정수" 처럼 직위가 앞에 오는 경우
    if ($out['name'] === '' && $out['position'] !== ''
        && preg_match('/^(' . $posWords . ')\s+([가-힣]{2,4})$/u', $out['position'], $m)) {
        $out['position'] = $m[1];
        $out['name']     = $m[2];
    }
    // 부서 자리에 인명이 들어온 경우 보정 (조직 접미사가 없는 2~4자 한글)
    if ($out['dept_name'] !== ''
        && preg_match('/^[가-힣]{2,4}$/u', $out['dept_name'])
        && !preg_match('/(팀|부|과|실|국|단|원|소|처|본부|센터|그룹|사업부|연구)$/u', $out['dept_name'])) {
        if ($out['name'] === '') {
            $out['name'] = $out['dept_name'];
        }
        $out['dept_name'] = '';
    }

    /* 8) 이름 ----------------------------------------------------- */
    if ($out['name'] === '') {
        $cands = [];
        foreach ($lines as $i => $l) {
            if ($l === $out['company_name'] || $l === $out['address']) {
                continue;
            }
            if (preg_match('/@|https?:|\d/u', $l)) {
                continue;
            }
            // "David Kim / Manager" 처럼 이름과 직위가 / 로 나뉜 경우
            if (strpos($l, '/') !== false) {
                $left = trim(explode('/', $l, 2)[0]);
                if (preg_match('/^[A-Za-z][A-Za-z.\-]*(?:\s+[A-Za-z][A-Za-z.\-]*){0,2}$/u', $left)
                    && !preg_match('/' . $corpWords . '/iu', $left)) {
                    $cands[] = ['name' => $left, 'score' => 8 + max(0, 5 - $i)];
                    continue;
                }
            }
            // 영문 이름 단독 줄 (2~3 단어, 회사/직위 단어 없음)
            if (preg_match('/^[A-Z][A-Za-z.\-]+(?:\s+[A-Z][A-Za-z.\-]+){1,2}$/u', $l)
                && !preg_match('/' . $corpWords . '|Team|Dept|Division|Sales|Manager|Director|Officer|Engineer/iu', $l)) {
                $cands[] = ['name' => $l, 'score' => 6 + max(0, 5 - $i)];
                continue;
            }
            $compact = preg_replace('/\s+/u', '', $l);
            // 한글 2~4자(또는 "신 유 철" 처럼 띄어쓴 형태)
            if (preg_match('/^[가-힣]{2,4}$/u', $compact)
                && !preg_match('/' . $posWords . '|' . $corpWords . '/u', $compact)) {
                $spaced = (bool) preg_match('/^(?:[가-힣]\s+){1,3}[가-힣]$/u', $l);
                $cands[] = ['name' => $compact, 'score' => ($spaced ? 10 : 5) + max(0, 5 - $i)];
            }
        }
        if ($cands) {
            usort($cands, static fn($a, $b) => $b['score'] <=> $a['score']);
            $out['name'] = $cands[0]['name'];
        }
    }

    /* 9) 회사명 보완 : 이메일 도메인으로 추정 근거 남기지 않음 ------- */
    foreach ($out as $k => $v) {
        $out[$k] = is_string($v) ? trim($v) : $v;
    }
    return $out;
}
