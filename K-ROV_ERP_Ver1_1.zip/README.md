# 사내 ERP (SME WEB ERP) v1.1.0

중소기업(20명 내외) 내부 업무용 ERP입니다. **PHP 8 + MariaDB + 순수 HTML/CSS/JS**로만 구성되어
CAFE24 같은 일반 리눅스 웹호스팅에 FTP 업로드만으로 동작합니다. (Node.js·빌드도구·프레임워크 불필요)

## 1. 구성 모듈

| 모듈 | 주요 기능 |
|---|---|
| 대시보드 | 오늘/이번 달 입출금, 월 매출·매입, 재직 인원, 최근 거래, 6개월 추이 그래프 |
| 인사관리 | 사원 등록·수정·검색·상태변경, 부서/직급 관리, CSV 다운로드 |
| 금융관리 | 은행 거래내역(검색·합계·분류 일괄변경), 거래 등록, **CSV 업로드(컬럼 매핑·중복검사)**, 계좌/거래분류 관리 |
| 거래처관리 | 매입처·매출처 통합 관리, 누적 매출/매입 집계 |
| 명함/담당자 | **명함 사진 OCR 등록**(CLOVA/Google/브라우저), 항목 자동 추출 후 확인·수정, 거래처·담당자 자동 생성, 명함함 |
| 매입/매출 | 전표 + 품목 다중행, 부가세 자동계산, 상태(임시/확정/지급·수금/취소), 미수·미지급 추적 |
| 통계 | 기간별 종합, 입출금(분류·계좌·일자별), 매입/매출(거래처별), 사원, CSV 다운로드 |
| 관리자 | 사용자 계정, 역할×권한 매트릭스, 메뉴 관리, 활동/로그인 로그, 환경설정 |

## 2. 기술 스택

- PHP 8.x (PDO, prepared statement 전용)
- MariaDB 10.x / MySQL 5.7+ (InnoDB, utf8mb4)
- 프런트엔드: 순수 HTML/CSS/JS, 그래프만 Chart.js 4.4.1 (CDN, 대시보드·통계 화면에서만 로드)
- 명함 OCR: NAVER CLOVA OCR / Google Vision (서버 cURL) 또는 Tesseract.js (브라우저, CDN)
- 외부 프레임워크·패키지 매니저 사용 안 함

## 3. 폴더 구조

```
/erp
├── index.php          진입점(로그인 여부에 따라 분기)
├── login.php / logout.php
├── setup.php          최초 1회 설치 (설치 후 삭제 권장)
├── config/            설정 (config.php, database.php) ※ 웹 접근 차단
├── includes/          공통 모듈 ※ 웹 접근 차단
│   ├── bootstrap.php  모든 페이지가 이 파일 하나만 require
│   ├── db.php         PDO 커넥션 + 쿼리 헬퍼
│   ├── auth.php       세션 · 로그인 · CSRF
│   ├── permission.php 권한 검사(require_perm)
│   ├── functions.php  escape · 검증 · 페이징 · 포맷 · 설정
│   ├── csv.php        CSV Import/Export
│   ├── ocr.php        명함 OCR 엔진 연동(CLOVA/Google/브라우저)
│   ├── card_parser.php 명함 원문 → 이름·회사·연락처 추출
│   ├── logger.php     활동/로그인 로그
│   └── header.php · sidebar.php · footer.php
├── assets/css, assets/js
├── modules/           dashboard, employees, banking, clients, purchases, sales, statistics, admin
├── api/               clients.php(자동완성), stats.php(차트), card_parse.php(명함 항목 추출)
├── uploads/           CSV 임시 저장 ※ 스크립트 실행 차단
│   └── cards/         명함 원본 ※ 직접 접근 전면 차단(card_image.php 경유만 허용)
├── logs/              PHP 오류 로그 ※ 웹 접근 차단
└── sql/               schema.sql, seed.sql
```

## 4. 설치

`INSTALL.md` 참고. 요약하면:

1. DB 생성 후 `sql/schema.sql` → `sql/seed.sql` 순서로 import
2. `config/database.php` 접속정보 수정 (운영 시 `APP_ENV`를 `production`으로)
3. FTP 업로드 후 `uploads/`, `logs/`, `config/` 쓰기 권한 부여
4. 브라우저에서 `setup.php` 실행 → 최고관리자 계정 생성
5. `setup.php` 삭제, HTTPS 적용

## 5. 보안 설계 요약

- 모든 쿼리 PDO prepared statement (`EMULATE_PREPARES=false`)
- 비밀번호 `password_hash()` / `password_verify()`, 로그인 실패 누적 시 계정 잠금
- 모든 POST에 CSRF 토큰 검증, 로그인 성공 시 `session_regenerate_id()`
- 모든 출력에 `h()` (htmlspecialchars) 적용
- 화면 노출과 별개로 **서버에서 `require_perm()` 재검사** (URL 직접 입력 차단)
- 운영환경 오류 메시지 비노출 + `logs/php_error.log` 기록
- 주요 데이터 변경·CSV 다운로드·권한 거부는 `activity_logs`에 기록
- 삭제는 soft delete(`deleted_at`), 금액은 `DECIMAL(18,2)`
- 계좌번호 마스킹, CSV Formula Injection 방어, 업로드 디렉터리 PHP 실행 차단

## 6. 계정 권한

| 역할 | 범위 |
|---|---|
| SUPER_ADMIN | 전체 권한(코드 레벨 우회 허용), 시스템 설정·로그 정리 |
| ADMIN | 운영 전반 관리 |
| MANAGER | 업무 데이터 등록·수정 + 통계 |
| EMPLOYEE | 조회 중심 |

권한은 `관리자 → 권한 관리`에서 기능 단위(예: `bank.import`)로 조정합니다.

## 7. 명함 OCR 사용법

1. `관리자 → 환경 설정 → 명함 OCR`에서 인식 엔진 선택
   - **BROWSER**(기본): API 키 없이 즉시 사용. 사용자 브라우저에서 Tesseract.js가 인식하므로 비용 0, 정확도는 보통.
   - **CLOVA**: NAVER CLOUD 콘솔에서 CLOVA OCR 도메인(명함 모델) 생성 → Invoke URL + Secret 입력. 한글 명함 정확도가 가장 높음.
   - **GOOGLE**: Google Cloud Vision API Key 입력.
   - **MANUAL**: 이미지만 보관하고 직접 입력.
2. `거래처관리 → 명함 등록(OCR)`에서 사진 업로드(휴대폰은 바로 촬영 가능)
3. 자동 추출된 이름·회사·부서·직위·휴대전화·유선전화·팩스·이메일·홈페이지·우편번호·주소를 **확인·수정**
4. 거래처 연결 방식 선택 → 저장하면 담당자가 등록되고, 필요 시 거래처가 자동 생성됨

> OCR 결과는 절대 그대로 저장되지 않습니다. 반드시 확인 화면을 거치며, 원문은 `business_cards.ocr_text`에 보관되어 언제든 재추출할 수 있습니다.

## 8. 다음 단계(v1.2 이후 후보)

- 은행 오픈API 자동 수집(현재는 CSV Import로 대체, 저장 로직 재사용 가능)
- 세금계산서 발행 연동, 결재선/승인 워크플로
- 미수금 알림, 엑셀(xlsx) 직접 출력, 첨부파일 관리
- 명함 일괄 업로드(여러 장 동시), 중복 담당자 자동 병합, vCard(.vcf) 내보내기
