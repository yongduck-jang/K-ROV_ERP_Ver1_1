-- =====================================================================
--  SME WEB ERP  v1.0.0 → v1.1.0 업그레이드
--  추가 기능 : 명함 OCR 등록 (business_cards) + 거래처 담당자 (client_contacts)
--  ※ 신규 설치라면 schema.sql / seed.sql 에 이미 포함되어 있으므로 실행 불필요.
--  ※ 실행 전 반드시 DB 백업.
-- =====================================================================
SET NAMES utf8mb4;

-- 1) 거래처 담당자 -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `client_contacts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id`   INT UNSIGNED     NULL              COMMENT '연결 거래처(미지정 허용)',
  `name`        VARCHAR(50)  NOT NULL,
  `company_name` VARCHAR(100)    NULL              COMMENT '명함에 적힌 회사명(거래처 미연결 시 보관)',
  `dept_name`   VARCHAR(100)     NULL              COMMENT '부서/조직',
  `position`    VARCHAR(60)      NULL              COMMENT '직위/직책',
  `mobile`      VARCHAR(30)      NULL,
  `tel`         VARCHAR(30)      NULL,
  `fax`         VARCHAR(30)      NULL,
  `email`       VARCHAR(120)     NULL,
  `homepage`    VARCHAR(200)     NULL,
  `zipcode`     VARCHAR(10)      NULL,
  `address`     VARCHAR(255)     NULL,
  `memo`        VARCHAR(500)     NULL,
  `is_primary`  TINYINT(1)   NOT NULL DEFAULT 0    COMMENT '거래처 대표 담당자',
  `status`      ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  `created_by`  INT UNSIGNED     NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`  DATETIME         NULL,
  PRIMARY KEY (`id`),
  KEY `idx_contact_client` (`client_id`),
  KEY `idx_contact_name` (`name`),
  KEY `idx_contact_mobile` (`mobile`),
  KEY `idx_contact_email` (`email`),
  CONSTRAINT `fk_contact_client` FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='거래처 담당자(명함)';

-- 2) 명함 원본/인식결과 -------------------------------------------------
CREATE TABLE IF NOT EXISTS `business_cards` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `file_name`    VARCHAR(120) NOT NULL              COMMENT '서버 저장 파일명(uploads/cards)',
  `orig_name`    VARCHAR(160)     NULL,
  `mime_type`    VARCHAR(40)      NULL,
  `file_size`    INT UNSIGNED NOT NULL DEFAULT 0,
  `ocr_provider` VARCHAR(20)  NOT NULL DEFAULT 'MANUAL' COMMENT 'CLOVA/GOOGLE/BROWSER/MANUAL',
  `ocr_status`   ENUM('PENDING','DONE','FAILED') NOT NULL DEFAULT 'PENDING',
  `ocr_message`  VARCHAR(255)     NULL              COMMENT '실패 사유',
  `ocr_text`     TEXT             NULL              COMMENT '인식 원문',
  `parsed_json`  TEXT             NULL              COMMENT '항목 추출 결과(JSON)',
  `contact_id`   INT UNSIGNED     NULL,
  `client_id`    INT UNSIGNED     NULL,
  `created_by`   INT UNSIGNED     NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`   DATETIME         NULL,
  PRIMARY KEY (`id`),
  KEY `idx_card_contact` (`contact_id`),
  KEY `idx_card_client` (`client_id`),
  KEY `idx_card_status` (`ocr_status`,`deleted_at`),
  CONSTRAINT `fk_card_contact` FOREIGN KEY (`contact_id`) REFERENCES `client_contacts`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_card_client`  FOREIGN KEY (`client_id`)  REFERENCES `clients`(`id`)         ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='명함 이미지 및 OCR 결과';

-- 3) 권한 추가 ---------------------------------------------------------
INSERT IGNORE INTO `permissions` (`perm_key`,`perm_name`,`perm_group`,`sort_order`) VALUES
('contact.view','담당자 조회','거래처관리',44),
('contact.manage','담당자 등록/수정','거래처관리',45),
('card.view','명함 조회','거래처관리',46),
('card.create','명함 등록(OCR)','거래처관리',47),
('card.delete','명함 삭제','거래처관리',48);

-- SUPER_ADMIN / ADMIN : 전체
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
  ON p.perm_key IN ('contact.view','contact.manage','card.view','card.create','card.delete')
WHERE r.role_key IN ('SUPER_ADMIN','ADMIN');

-- MANAGER : 삭제 제외
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
  ON p.perm_key IN ('contact.view','contact.manage','card.view','card.create')
WHERE r.role_key = 'MANAGER';

-- EMPLOYEE : 조회만 (명함 이미지에는 개인정보가 있으므로 담당자 정보만 허용)
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p ON p.perm_key = 'contact.view'
WHERE r.role_key = 'EMPLOYEE';

-- 4) 메뉴 추가 ---------------------------------------------------------
INSERT IGNORE INTO `menus` (`id`,`parent_id`,`menu_name`,`menu_url`,`icon`,`sort_order`,`permission_key`,`visible`) VALUES
(23,20,'명함 등록(OCR)','/modules/clients/card_upload.php',NULL,30,'card.create',1),
(24,20,'명함함','/modules/clients/cards.php',NULL,40,'card.view',1),
(25,20,'담당자 목록','/modules/clients/contacts.php',NULL,50,'contact.view',1);

-- 5) OCR 환경설정 ------------------------------------------------------
INSERT IGNORE INTO `settings` (`setting_key`,`setting_value`,`setting_group`,`description`) VALUES
('ocr_provider','BROWSER','OCR','명함 인식 엔진(CLOVA/GOOGLE/BROWSER/MANUAL)'),
('ocr_clova_url','','OCR','NAVER CLOVA OCR APIGW Invoke URL'),
('ocr_clova_secret','','OCR','CLOVA OCR X-OCR-SECRET'),
('ocr_google_key','','OCR','Google Cloud Vision API Key'),
('ocr_max_mb','4','OCR','명함 이미지 최대 용량(MB)'),
('card_keep_image','1','OCR','명함 원본 이미지 보관(0이면 인식 후 삭제)');
