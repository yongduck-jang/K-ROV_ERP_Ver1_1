<?php
/**
 * /includes/ocr.php
 * 명함 OCR 엔진 연동 계층.
 *
 * 지원 엔진 (관리자 → 환경설정 에서 선택)
 *   CLOVA   : NAVER CLOVA OCR (명함 특화 모델). 한글 명함 인식률이 가장 좋음. 유료/API 키 필요.
 *   GOOGLE  : Google Cloud Vision (DOCUMENT_TEXT_DETECTION). 유료/API 키 필요.
 *   BROWSER : Tesseract.js 로 사용자 브라우저에서 인식. 서버 비용 0, 정확도는 낮음.
 *   MANUAL  : OCR 없이 이미지만 저장하고 직접 입력.
 *
 * 어떤 엔진을 쓰든 결과는 "원문 텍스트 + 추출 항목" 형태로 통일되며,
 * 사용자가 확인·수정한 뒤에 저장하므로 오인식이 그대로 DB에 들어가지 않는다.
 */

function ocr_provider(): string
{
    return pick((string) setting('ocr_provider', 'BROWSER'), ['CLOVA', 'GOOGLE', 'BROWSER', 'MANUAL'], 'BROWSER');
}

function ocr_provider_label(string $p): string
{
    $map = ['CLOVA' => 'NAVER CLOVA OCR', 'GOOGLE' => 'Google Vision', 'BROWSER' => '브라우저 인식(Tesseract.js)', 'MANUAL' => '직접 입력'];
    return $map[$p] ?? $p;
}

/** 서버측 OCR 사용 가능 여부(키가 채워져 있는지) */
function ocr_server_ready(?string $provider = null): bool
{
    $p = $provider ?? ocr_provider();
    if ($p === 'CLOVA') {
        return setting('ocr_clova_url', '') !== '' && setting('ocr_clova_secret', '') !== '';
    }
    if ($p === 'GOOGLE') {
        return setting('ocr_google_key', '') !== '';
    }
    return false;
}

/**
 * 이미지 파일을 OCR 처리한다.
 * @return array{ok:bool, text:string, fields:array, message:string}
 */
function ocr_run(string $imagePath, ?string $provider = null): array
{
    $p = $provider ?? ocr_provider();
    $fail = static fn(string $m): array => ['ok' => false, 'text' => '', 'fields' => [], 'message' => $m];

    if (!is_file($imagePath)) {
        return $fail('이미지 파일을 찾을 수 없습니다.');
    }
    if ($p === 'CLOVA') {
        return ocr_clova($imagePath);
    }
    if ($p === 'GOOGLE') {
        return ocr_google($imagePath);
    }
    // BROWSER / MANUAL 은 서버에서 처리하지 않는다.
    return ['ok' => true, 'text' => '', 'fields' => [], 'message' => ''];
}

/** 공통 HTTP POST (cURL). CAFE24에서 외부 API 호출이 막혀 있으면 실패 메시지를 남긴다. */
function ocr_http_post(string $url, string $body, array $headers, int $timeout = 25): array
{
    if (!function_exists('curl_init')) {
        return [0, '', 'cURL 확장이 설치되어 있지 않습니다.'];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $res  = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return [$code, (string) $res, $err];
}

/** NAVER CLOVA OCR (명함 도메인) */
function ocr_clova(string $imagePath): array
{
    $url    = (string) setting('ocr_clova_url', '');
    $secret = (string) setting('ocr_clova_secret', '');
    if ($url === '' || $secret === '') {
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => 'CLOVA OCR 설정(Invoke URL / Secret)이 비어 있습니다.'];
    }

    $ext  = strtolower(pathinfo($imagePath, PATHINFO_EXTENSION));
    $ext  = in_array($ext, ['jpg', 'jpeg', 'png'], true) ? ($ext === 'jpeg' ? 'jpg' : $ext) : 'jpg';
    $body = json_encode([
        'version'   => 'V2',
        'requestId' => bin2hex(random_bytes(8)),
        'timestamp' => (int) round(microtime(true) * 1000),
        'lang'      => 'ko',
        'images'    => [[
            'format' => $ext,
            'name'   => 'card',
            'data'   => base64_encode((string) file_get_contents($imagePath)),
        ]],
    ], JSON_UNESCAPED_UNICODE);

    [$code, $res, $err] = ocr_http_post($url, $body, ['Content-Type: application/json', 'X-OCR-SECRET: ' . $secret]);
    if ($code !== 200) {
        error_log('[ocr.clova] HTTP ' . $code . ' ' . $err . ' ' . mb_substr($res, 0, 300));
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => 'CLOVA OCR 호출 실패 (HTTP ' . $code . ')'];
    }

    $json  = json_decode($res, true);
    $image = $json['images'][0] ?? null;
    if (!$image) {
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => 'CLOVA OCR 응답을 해석할 수 없습니다.'];
    }

    $lines  = [];
    $fields = [];

    // (1) 명함 특화 모델 응답 : nameCard.result 에 항목이 구조화되어 온다.
    $nc = $image['nameCard']['result'] ?? null;
    if (is_array($nc)) {
        $grab = static function (array $nc, string $key): string {
            $items = $nc[$key] ?? [];
            $out   = [];
            foreach ((array) $items as $it) {
                if (is_array($it) && isset($it['text'])) {
                    $out[] = (string) $it['text'];
                } elseif (is_string($it)) {
                    $out[] = $it;
                }
            }
            return trim(implode(' ', $out));
        };
        $fields = array_filter([
            'name'         => $grab($nc, 'name'),
            'company_name' => $grab($nc, 'company'),
            'dept_name'    => $grab($nc, 'department'),
            'position'     => $grab($nc, 'position'),
            'mobile'       => $grab($nc, 'mobile'),
            'tel'          => $grab($nc, 'tel'),
            'fax'          => $grab($nc, 'fax'),
            'email'        => $grab($nc, 'email'),
            'homepage'     => $grab($nc, 'homepage'),
            'address'      => $grab($nc, 'address'),
        ], static fn($v) => $v !== '');
        $lines = array_values($fields);
    }

    // (2) 일반 OCR 필드(좌표 기반) → 줄 단위 원문 복원
    foreach (($image['fields'] ?? []) as $f) {
        $txt = trim((string) ($f['inferText'] ?? ''));
        if ($txt === '') {
            continue;
        }
        $lines[] = $txt;
        if (!empty($f['lineBreak'])) {
            $lines[] = "\n";
        }
    }
    $text = trim(preg_replace("/ *\n */", "\n", implode(' ', $lines)));

    // 구조화 결과가 비어 있으면 원문에서 직접 추출
    if (!$fields) {
        $fields = parse_card_text($text);
    } else {
        $fields = array_merge(parse_card_text($text), $fields);   // 구조화 결과 우선
    }
    return ['ok' => true, 'text' => $text, 'fields' => $fields, 'message' => ''];
}

/** Google Cloud Vision */
function ocr_google(string $imagePath): array
{
    $key = (string) setting('ocr_google_key', '');
    if ($key === '') {
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => 'Google Vision API Key 가 설정되어 있지 않습니다.'];
    }
    $body = json_encode([
        'requests' => [[
            'image'        => ['content' => base64_encode((string) file_get_contents($imagePath))],
            'features'     => [['type' => 'DOCUMENT_TEXT_DETECTION']],
            'imageContext' => ['languageHints' => ['ko', 'en']],
        ]],
    ]);
    [$code, $res, $err] = ocr_http_post(
        'https://vision.googleapis.com/v1/images:annotate?key=' . urlencode($key),
        $body, ['Content-Type: application/json']
    );
    if ($code !== 200) {
        error_log('[ocr.google] HTTP ' . $code . ' ' . $err);
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => 'Google Vision 호출 실패 (HTTP ' . $code . ')'];
    }
    $json = json_decode($res, true);
    $text = (string) ($json['responses'][0]['fullTextAnnotation']['text'] ?? '');
    if ($text === '') {
        return ['ok' => false, 'text' => '', 'fields' => [], 'message' => '이미지에서 글자를 찾지 못했습니다.'];
    }
    return ['ok' => true, 'text' => $text, 'fields' => parse_card_text($text), 'message' => ''];
}
